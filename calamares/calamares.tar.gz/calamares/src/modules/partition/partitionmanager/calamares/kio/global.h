#ifndef GLOBAL_H
#define GLOBAL_H

namespace KIO {

typedef qulonglong filesize_t;

}

#endif /* GLOBAL_H */
