force-quit
==========

Gnome Shell Extension To Add Force Quit button

About
=====

Adds a force quit button which launches xkill.

If you click it by mistake right click to undo or click on the panel.

You can customize its position by tweaking line 27 of extension.js


Tip
=====

You can right-click anywhere or click on the top panel to abort the kill.

Installation
============

Install it from the [extensions site](https://extensions.gnome.org/extension/770/force-quit/)
