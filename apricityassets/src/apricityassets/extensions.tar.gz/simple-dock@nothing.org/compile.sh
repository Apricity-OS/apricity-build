#!/bin/bash

glib-compile-schemas schemas

# msgfmt ./locale/en/LC_MESSAGES/en.po
# mv ./messages.mo ./locale/en/LC_MESSAGES/simple-dock.mo

# msgfmt ./locale/es/LC_MESSAGES/es.po
# mv ./messages.mo ./locale/es/LC_MESSAGES/simple-dock.mo
