#! /bin/sh
GNOME_SHELL_JS=/etc/apricity-assets/gnome-shell-js gnome-shell --replace
