## 0.1.0 - First Release
* Every feature added
* Every bug fixed
